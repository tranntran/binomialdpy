"""
Differentially Private Uniformly Most Powerful Test for Binomial Data
"""